# Servikal distoni — ücretsiz bulut başlangıç paketi

Bu paket **yalnızca OpenSim native kurulumunu sınar**. Eski checkpointler bulunmadığı için
fiziksel zamanı ilerletmez. 78 Thelen kas, 302 state, 30 coupler, H1 ve gözlemci
tutarlılığı ayrıca gerçek proje modeli ve checkpointlerle doğrulanmalıdır.

## Android'den kurulum
1. GitHub hesabında **private** bir repository oluştur: `servikal-distoni-native`.
2. Bu ZIP'i açıp `.github/workflows/native_check.yml`, `scripts/verify_wheel.py`,
   `scripts/native_probe.py` dosyalarını aynı dizin yollarıyla repository'ye ekle.
3. GitHub > repository > Actions > OpenSim native doğrulama > Run workflow.
4. Çalışma bitince Artifacts bölümündeki `opensim-native-probe` raporunu incele.
5. Wheel hash eşleşmiyorsa yükleme bilinçli olarak durur; hash'i rastgele değiştirme.

**Not:** GitHub Actions runner geçicidir; 2.000 dakika/ay (kişisel Free özel repo,
standart runner) kota sınırıdır. Kalıcı checkpoint için Drive/başka dayanıklı depoya
atomik yedekleme ve bağımsız geri okuma kurulmadan gerçek simülasyona geçilmemelidir.
Bu paket GitHub'a yüklenmiş veya orada çalıştırılmış değildir.
